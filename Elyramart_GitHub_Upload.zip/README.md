# Elyramart Android Marketplace — v0.9 APK Build Setup

This package contains the current Flutter source, Firebase backend/rules, and a GitHub Actions workflow that generates the missing Android host project and builds a release APK in GitHub's cloud runner.

**This is not a completed production marketplace.** The current UI remains a local demo and is not fully wired to Firebase. Firebase owner configuration, live auth/checkout/seller/admin UI integration, emulator tests and physical-device tests remain launch blockers.

For phone-only APK build instructions, read `BUILD_APK_BN.md`.
For current backend changes, read `V08_CHANGELOG_BN.md`.
Never grant admin privileges from the client app. Assign the first admin through a trusted Firebase Admin SDK environment.
