const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
initializeApp();
const db = getFirestore();

async function requireAdmin(uid) {
  const snap = await db.doc(`users/${uid}`).get();
  if (!snap.exists || snap.data().role !== 'admin') throw new HttpsError('permission-denied', 'Admin access required.');
}

exports.approveSeller = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in required.');
  await requireAdmin(request.auth.uid);
  const { applicationId, sellerUid } = request.data || {};
  if (!applicationId || !sellerUid) throw new HttpsError('invalid-argument', 'applicationId and sellerUid are required.');
  await db.runTransaction(async (tx) => {
    const appRef = db.doc(`sellerApplications/${applicationId}`);
    const userRef = db.doc(`users/${sellerUid}`);
    const app = await tx.get(appRef);
    if (!app.exists || app.data().uid !== sellerUid || app.data().status !== 'pending') throw new HttpsError('failed-precondition', 'Pending seller application not found.');
    tx.update(appRef, { status: 'approved', reviewedAt: FieldValue.serverTimestamp(), reviewedBy: request.auth.uid });
    tx.set(userRef, { role: 'seller', sellerStatus: 'approved' }, { merge: true });
  });
  return { ok: true };
});

exports.approveProduct = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in required.');
  await requireAdmin(request.auth.uid);
  const { productId } = request.data || {};
  if (!productId) throw new HttpsError('invalid-argument', 'productId is required.');
  const productRef = db.doc(`products/${productId}`);
  const productSnap = await productRef.get();
  if (!productSnap.exists || productSnap.data().status !== 'pending') throw new HttpsError('failed-precondition', 'Pending product not found.');
  await productRef.update({ status: 'approved', reviewedAt: FieldValue.serverTimestamp(), reviewedBy: request.auth.uid });
  return { ok: true };
});

// Secure COD checkout: validate product prices/stock on the server and
// decrement stock transactionally. The client cannot write orders directly.
exports.createCodOrder = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in required.');
  const { items, customerName, phone, deliveryAddress } = request.data || {};
  if (!Array.isArray(items) || items.length < 1 || items.length > 30 ||
      typeof customerName !== 'string' || customerName.trim().length < 2 || customerName.trim().length > 80 ||
      typeof phone !== 'string' || !/^\+?[0-9\s-]{8,18}$/.test(phone.trim()) ||
      typeof deliveryAddress !== 'string' || deliveryAddress.trim().length < 8 || deliveryAddress.trim().length > 500) {
    throw new HttpsError('invalid-argument', 'Valid customer name, phone, address and order items are required.');
  }
  const quantities = new Map();
  for (const item of items) {
    const id = String(item.productId || '');
    const qty = Number(item.quantity);
    if (!/^[A-Za-z0-9_-]{10,128}$/.test(id) || !Number.isInteger(qty) || qty < 1 || qty > 99) {
      throw new HttpsError('invalid-argument', 'Invalid order item.');
    }
    const combined = (quantities.get(id) || 0) + qty;
    if (combined > 99) throw new HttpsError('invalid-argument', 'Maximum quantity per product is 99.');
    quantities.set(id, combined);
  }
  const orderRef = db.collection('orders').doc();
  let result;
  await db.runTransaction(async (tx) => {
    const productRefs = [...quantities.keys()].map(id => db.doc(`products/${id}`));
    const snaps = await Promise.all(productRefs.map(ref => tx.get(ref)));
    let subtotal = 0;
    const orderItems = [];
    const sellerUids = new Set();
    snaps.forEach((snap, i) => {
      if (!snap.exists) throw new HttpsError('not-found', 'A product no longer exists.');
      const product = snap.data();
      const quantity = quantities.get(productRefs[i].id);
      if (product.status !== 'approved' || !Number.isInteger(product.stock) || product.stock < quantity ||
          typeof product.sellerUid !== 'string' || !product.sellerUid) {
        throw new HttpsError('failed-precondition', 'A product is unavailable or out of stock.');
      }
      const price = Number(product.price);
      if (!Number.isSafeInteger(price) || price <= 0 || price > 10000000) throw new HttpsError('failed-precondition', 'Invalid product price.');
      subtotal += price * quantity;
      if (!Number.isSafeInteger(subtotal) || subtotal > 100000000) {
        throw new HttpsError('failed-precondition', 'Order total exceeds the allowed limit.');
      }
      sellerUids.add(product.sellerUid);
      orderItems.push({ productId: productRefs[i].id, name: product.name, unitPrice: price, quantity, sellerUid: product.sellerUid });
      tx.update(productRefs[i], { stock: Number(product.stock) - quantity });
    });
    const deliveryFee = 80;
    result = { orderId: orderRef.id, subtotal, deliveryFee, total: subtotal + deliveryFee };
    tx.create(orderRef, {
      customerUid: request.auth.uid,
      customerName: String(customerName).trim(),
      phone: String(phone).trim(),
      deliveryAddress: String(deliveryAddress).trim(),
      sellerUids: [...sellerUids],
      items: orderItems,
      subtotal,
      deliveryFee,
      total: subtotal + deliveryFee,
      paymentMethod: 'cod',
      status: 'placed',
      createdAt: FieldValue.serverTimestamp(),
    });
  });
  return result;
});


// Controlled order status changes. Sellers can update orders containing their
// products; only admins can set final administrative states such as delivered.
exports.updateOrderStatus = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in required.');
  const { orderId, status } = request.data || {};
  const allowed = ['confirmed', 'preparing', 'shipped', 'delivered'];
  if (!orderId || !allowed.includes(status)) {
    throw new HttpsError('invalid-argument', 'Invalid order or status.');
  }
  const orderRef = db.doc(`orders/${orderId}`);
  await db.runTransaction(async (tx) => {
    const orderSnap = await tx.get(orderRef);
    if (!orderSnap.exists) throw new HttpsError('not-found', 'Order not found.');
    const order = orderSnap.data();
    const userSnap = await tx.get(db.doc(`users/${request.auth.uid}`));
    const role = userSnap.exists ? userSnap.data().role : 'customer';
    const isAdmin = role === 'admin';
    const isSeller = role === 'seller' && order.sellerUids?.length === 1 && order.sellerUids[0] === request.auth.uid
      && (order.items || []).every(item => item.sellerUid === request.auth.uid);
    if (!isAdmin && !isSeller) throw new HttpsError('permission-denied', 'Not allowed to manage this order.');
    const transitions = { placed: ['confirmed'], confirmed: ['preparing'], preparing: ['shipped'], shipped: ['delivered'] };
    if (!(transitions[order.status] || []).includes(status)) {
      throw new HttpsError('failed-precondition', `Cannot change order from ${order.status} to ${status}.`);
    }
    if (!isAdmin && !['confirmed', 'preparing', 'shipped'].includes(status)) {
      throw new HttpsError('permission-denied', 'Seller cannot set this status.');
    }
    tx.update(orderRef, {
      status,
      updatedAt: FieldValue.serverTimestamp(),
      updatedBy: request.auth.uid,
    });
  });
  return { ok: true };
});

// Admin cancellation restores reserved stock atomically. This is separate from
// status updates so cancellation can never bypass the stock-restoration path.
exports.adminCancelOrder = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in required.');
  await requireAdmin(request.auth.uid);
  const { orderId } = request.data || {};
  if (!orderId) throw new HttpsError('invalid-argument', 'orderId is required.');
  const orderRef = db.doc(`orders/${orderId}`);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(orderRef);
    if (!snap.exists) throw new HttpsError('not-found', 'Order not found.');
    const order = snap.data();
    if (['shipped', 'delivered', 'cancelled'].includes(order.status)) {
      throw new HttpsError('failed-precondition', 'Shipped or closed orders require a return workflow and cannot be cancelled here.');
    }
    const refs = (order.items || []).map(item => db.doc(`products/${item.productId}`));
    const products = await Promise.all(refs.map(ref => tx.get(ref)));
    products.forEach((product, i) => {
      if (!product.exists || !Number.isInteger(product.data().stock) || !Number.isInteger(order.items[i].quantity)) {
        throw new HttpsError('failed-precondition', 'A product record is missing or invalid; cancellation was not applied.');
      }
      tx.update(refs[i], { stock: product.data().stock + order.items[i].quantity });
    });
    tx.update(orderRef, { status: 'cancelled', cancelledAt: FieldValue.serverTimestamp(), updatedBy: request.auth.uid });
  });
  return { ok: true };
});

// Customer cancellation is allowed only while the order is still placed.
// Product stock is restored in the same transaction to avoid partial updates.
exports.cancelMyOrder = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in required.');
  const { orderId } = request.data || {};
  if (!orderId) throw new HttpsError('invalid-argument', 'orderId is required.');
  const orderRef = db.doc(`orders/${orderId}`);
  await db.runTransaction(async (tx) => {
    const orderSnap = await tx.get(orderRef);
    if (!orderSnap.exists || orderSnap.data().customerUid !== request.auth.uid) {
      throw new HttpsError('not-found', 'Order not found.');
    }
    const order = orderSnap.data();
    if (order.status !== 'placed') {
      throw new HttpsError('failed-precondition', 'Only newly placed orders can be cancelled.');
    }
    const productRefs = (order.items || []).map(item => db.doc(`products/${item.productId}`));
    const productSnaps = await Promise.all(productRefs.map(ref => tx.get(ref)));
    productSnaps.forEach((snap, index) => {
      if (!snap.exists || !Number.isInteger(snap.data().stock) || !Number.isInteger(order.items[index].quantity)) {
        throw new HttpsError('failed-precondition', 'A product record is missing or invalid; cancellation was not applied.');
      }
      tx.update(productRefs[index], { stock: snap.data().stock + order.items[index].quantity });
    });
    tx.update(orderRef, {
      status: 'cancelled',
      cancelledAt: FieldValue.serverTimestamp(),
      updatedBy: request.auth.uid,
    });
  });
  return { ok: true };
});
