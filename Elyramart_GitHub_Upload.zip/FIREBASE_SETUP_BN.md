# Elyramart — Firebase সংযোগ ও বাস্তব লঞ্চের বাকি কাজ

এই v0.4 প্যাকেজে Firestore/Storage নিরাপত্তা নিয়ম, প্রয়োজনীয় index এবং server-side admin approval Cloud Functions-এর প্রাথমিক কোড যোগ করা হয়েছে। **এগুলো এখনো Firebase project-এ deploy করা হয়নি এবং Flutter UI-তে Firebase login/database যুক্ত হয়নি।** তাই এখনই বাস্তব অর্ডার নেওয়া নিরাপদ নয়।

## যা মালিকের অ্যাকাউন্টে করতে হবে
1. নিজের Google account দিয়ে Firebase Console-এ project তৈরি করুন (নাম: `elyramart-prod` বা উপলব্ধ নাম)।
2. Android app package name স্থির করুন। Firebase Android app যোগ করে `google-services.json` ডাউনলোড করুন।
3. Authentication-এ Phone sign-in চালু করুন; SMS quota/billing/দেশভিত্তিক নিয়ম যাচাই করুন।
4. Firestore Database ও Storage তৈরি করুন; production mode বেছে নিন।
5. Firebase CLI দিয়ে `firebase login`, `firebase use --add`, তারপর `firebase deploy --only firestore:rules,firestore:indexes,storage` চালান।
6. `firebase/functions`-এ গিয়ে `npm install`; এরপর `firebase deploy --only functions` চালান।
7. প্রথম Admin account নিরাপদভাবে তৈরি করে তার `users/{uid}` document-এ `role: admin` দিন। কখনো client app-কে নিজে admin role লেখার অনুমতি দেবেন না।

## ডেটা কাঠামো
- `users/{uid}`: name, phone, role(customer/seller/admin), sellerStatus
- `sellerApplications/{id}`: uid, shopName, ownerName, phone, address, status(pending/approved/rejected)
- `products/{id}`: sellerUid, name, category, price, imageUrl, stock, status(pending/approved/rejected), createdAt
- `orders/{id}`: customerUid, sellerUids, items, subtotal, deliveryFee, total, address, phone, paymentMethod(cod), status, createdAt

## বাস্তব লঞ্চের আগে আবশ্যক
- Flutter app-এ Firebase Auth, Firestore, Storage এবং callable functions integration সম্পন্ন করা
- Admin login আলাদা করে role-based route ও server-side authorization
- Cart/checkout-এ stock ও মূল্য সার্ভারে পুনরায় যাচাই; এখনকার demo cart নিরাপদ নয়
- Seller payout/commission, delivery charge, cancellation/refund এবং medicine sale-এর প্রযোজ্য আইন/লাইসেন্স যাচাই
- Privacy policy, terms, customer support, data deletion process
- বাস্তব ডিভাইসে QA, signed AAB, Play Console review
- bKash/Nagad merchant onboarding ও credentials ছাড়া payment চালু করা যাবে না; আপাতত COD only

## গুরুত্বপূর্ণ নিরাপত্তা
Firebase config ফাইল, service account key, Play signing key, OTP বা password কাউকে প্রকাশ করবেন না। Admin UID ও merchant credentials চ্যাটে পাঠাবেন না। Firebase project ও Play Console আপনার নিজের নিয়ন্ত্রণে রাখুন।

## v0.5: Flutter backend service layer
`lib/backend/marketplace_service.dart`-এ ফোন OTP login, customer profile, approved product stream, seller application, product submission, COD order request এবং admin approval callable methods যোগ হয়েছে। `pubspec.yaml`-এ Firebase packages যোগ করা হয়েছে। UI এখনো এই service layer-এ wired নয়; অর্থাৎ শুধু dependency যোগ করলেই demo screen live হবে না।

### Flutter app configure করার কমান্ড
প্রথমবার project folder-এ:
```bash
flutter create .
dart pub global activate flutterfire_cli
flutterfire configure
flutter pub get
```
`flutterfire configure`-এ নিজের Firebase project ও Android app নির্বাচন করুন। এটি `lib/firebase_options.dart` তৈরি করবে। ফোনে শুধু ZIP ডাউনলোড করে Firebase project configure করা সম্ভব নয়; Flutter SDK/CLI-সহ কম্পিউটার বা cloud development environment লাগবে।

### Backend deploy
```bash
cd firebase/functions
npm install
cd ../..
firebase login
firebase use --add
firebase deploy --only firestore:rules,firestore:indexes,storage,functions
```
Cloud Functions deploy করতে Firebase project-এ billing/Blaze plan লাগতে পারে। আগে Firebase-এর বর্তমান pricing ও region availability যাচাই করুন।

### COD checkout security
এখন `orders` collection-এ client সরাসরি order লিখতে পারবে না। `createCodOrder` callable function server-side product status, দাম ও stock যাচাই করে transaction-এ stock কমায় এবং COD order তৈরি করে। ডেলিভারি চার্জ বর্তমানে demo default ৳80; ব্যবসার প্রকৃত নীতির সঙ্গে মিলিয়ে deploy-এর আগে পরিবর্তন করতে হবে।

### Admin নিরাপত্তা
প্রথম admin account Firebase Authentication দিয়ে তৈরি করে নিরাপদ পদ্ধতিতে Firestore `users/{uid}` document-এ `role: "admin"` সেট করতে হবে। Admin role কখনো অ্যাপ UI থেকে self-assign করা যাবে না।
