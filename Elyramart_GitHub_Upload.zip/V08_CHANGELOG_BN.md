# Elyramart v0.8 — Backend Validation Update

## এই ভার্সনে করা পরিবর্তন
- COD order function-এ নাম, ফোন, ঠিকানা ও item validation শক্ত করা হয়েছে।
- একই পণ্যের duplicate line একত্র করার পরও quantity 99-এর বেশি হতে পারবে না।
- Product document ID format, seller UID, stock integer এবং price range যাচাই করা হয়।
- Order subtotal-এর নিরাপদ সর্বোচ্চ সীমা যোগ করা হয়েছে।
- Admin/Customer cancellation-এ কোনো product record বা stock value অনুপস্থিত/ভুল হলে transaction বাতিল হবে; আংশিক stock restore হবে না।
- Backend JavaScript syntax check চালানো হয়েছে (`node --check`)।

## এখনো লাইভ চালুর আগে আবশ্যক
এই ZIP একটি Flutter source project-এর অসম্পূর্ণ development package। এটি APK নয়। Live marketplace চালু করতে এখনও:
1. Flutter SDK-তে Android platform/Gradle wrapper তৈরি করতে হবে (`flutter create .` দিয়ে সঠিক project structure-এ)।
2. মালিকের Firebase project তৈরি করে Android app নিবন্ধন ও FlutterFire configuration (`firebase_options.dart`, google-services config) দিতে হবে।
3. `lib/main.dart`-এর বর্তমান local demo UI-কে `MarketplaceService`-এর Auth/Firestore/Storage/Functions stream ও actions-এর সঙ্গে সম্পূর্ণ যুক্ত করতে হবে।
4. Customer cart-এ product ID ও quantity, checkout form, seller order queue, admin approvals/order dashboard এবং product image upload UI বাস্তবায়ন করতে হবে।
5. Firebase Emulator rules/functions tests, Android APK build, physical device test, তারপর release signing করতে হবে।

## গুরুত্বপূর্ণ নিরাপত্তা
- অ্যাপের ভিতর থেকে কাউকে admin বানানোর ব্যবস্থা নেই এবং থাকা উচিত নয়। প্রথম admin trusted Firebase Admin SDK/Console দিয়ে owner নিজে সেট করবেন।
- ফোন OTP চালাতে Firebase Authentication-এ Phone provider enable ও billing/region availability যাচাই করতে হবে।
- COD delivery fee বর্তমানে backend-এ 80 BDT hard-coded; লাইভের আগে ব্যবসার সিদ্ধান্ত অনুযায়ী configuration-এ নিতে হবে।
- বর্তমান seller status workflow একাধিক seller-সহ order-কে seller-side processing করতে দেয় না; multi-seller checkout চালুর আগে seller-wise sub-order workflow বানাতে হবে অথবা এক seller per checkout enforce করতে হবে।
