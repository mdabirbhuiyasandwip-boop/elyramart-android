# Elyramart APK Build — মোবাইল থেকে

এই ZIP-এ GitHub Actions workflow যোগ করা আছে। GitHub-এ সোর্স আপলোড করলে GitHub-এর cloud runner Android APK build করবে। নিজের ফোনে Flutter/Android Studio ইনস্টল করতে হবে না।

## একবারের সেটআপ
1. GitHub অ্যাকাউন্টে একটি নতুন **Private repository** তৈরি করো; নাম `elyramart-android` রাখতে পারো।
2. এই ZIP Extract করো। ZIP-এর ভিতরের `elyramart_android` ফোল্ডারে ঢুকে **ভিতরের সব ফাইল ও ফোল্ডার** (বিশেষ করে `.github` ফোল্ডারসহ) repository-র root-এ আপলোড করো। `elyramart_android` নামের বাইরের ফোল্ডারটি repository-র ভিতরে রাখবে না।
3. GitHub repository-তে **Actions** tab খোলো। প্রথমবার workflow চালানোর অনুমতি চাইলে Allow করো।
4. `Build Elyramart Android APK` workflow নির্বাচন করে **Run workflow** চাপো। `main` বা `master` branch-এ ফাইল push করলেও স্বয়ংক্রিয়ভাবে build হবে।
5. Build শেষ হলে workflow run খুলে **Artifacts** অংশ থেকে `Elyramart-Android-APK` ডাউনলোড করো। ZIP extract করলে `app-release.apk` পাবে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি বর্তমানে বিদ্যমান Flutter demo UI-র APK build করার ব্যবস্থা; এটি production-ready marketplace নয়। Login, checkout, seller/admin dashboard এখনো live Firebase UI-তে সম্পূর্ণ যুক্ত হয়নি।
- Firebase project configuration না থাকায় এই APK Firebase-এ connect হবে না। Firebase live করার আগে Android app-টি Firebase project-এ register ও FlutterFire configure করতে হবে।
- Workflow Android platform/Gradle files cloud runner-এ তৈরি করে। তাই ZIP-এর ভিতরে Gradle wrapper না থাকলেও build pipeline তৈরি হতে পারে।
- GitHub account/repository তোমার নিয়ন্ত্রণে থাকবে। আমি তোমার GitHub-এ নিজে sign in বা repository create করতে পারি না।
- Play Store-এ প্রকাশের আগে Firebase setup, app testing, privacy policy, release signing এবং production checks আবশ্যক।
