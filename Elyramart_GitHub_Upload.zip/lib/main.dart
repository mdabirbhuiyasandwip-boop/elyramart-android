import 'package:flutter/material.dart';

void main() => runApp(const ElyramartApp());

const green = Color(0xFF087C50);
const darkGreen = Color(0xFF064E3B);
const pale = Color(0xFFE8F4ED);
const ink = Color(0xFF17211D);
const muted = Color(0xFF68756F);

class ElyramartApp extends StatelessWidget {
  const ElyramartApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Elyramart',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: green),
      scaffoldBackgroundColor: const Color(0xFFF7F9F8),
      appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: ink, elevation: 0),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: const Color(0xFFF1F5F3),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(13), borderSide: BorderSide.none),
      ),
    ),
    home: const RootPage(),
  );
}

class ShopProduct {
  ShopProduct({required this.name, required this.category, required this.price, required this.seller, this.approved = true});
  final String name, category, seller;
  final int price;
  bool approved;
}

class RootPage extends StatefulWidget {
  const RootPage({super.key});
  @override
  State<RootPage> createState() => _RootPageState();
}

class _RootPageState extends State<RootPage> {
  bool sellerMode = false;
  bool adminMode = false;
  bool isBengali = true;
  int tab = 0;
  int cart = 0;
  String query = '';
  String selectedCategory = 'All';
  String sellerStatus = 'Not registered';
  final search = TextEditingController();
  final products = <ShopProduct>[
    ShopProduct(name:'Wireless Earbuds', category:'Electronics', price:850, seller:'Tech Corner'),
    ShopProduct(name:'Daily Face Wash', category:'Beauty', price:350, seller:'Glow Store'),
    ShopProduct(name:'Cotton T-shirt', category:'Fashion', price:520, seller:'Urban Wear'),
    ShopProduct(name:'Kitchen Storage Set', category:'Home & Living', price:690, seller:'Home Needs'),
    ShopProduct(name:'Grocery Essentials Pack', category:'Grocery', price:780, seller:'Fresh Basket'),
    ShopProduct(name:'Digital Thermometer', category:'Health', price:290, seller:'Care Pharmacy'),
  ];
  final pending = <ShopProduct>[];
  final orders = <String>[];

  String t(String en, String bn) => isBengali ? bn : en;
  List<ShopProduct> get shown => products.where((p) =>
    p.approved &&
    (selectedCategory == 'All' || p.category == selectedCategory) &&
    (query.isEmpty || '${p.name} ${p.category} ${p.seller}'.toLowerCase().contains(query.toLowerCase()))
  ).toList();

  @override
  void dispose() { search.dispose(); super.dispose(); }

  void toast(String msg) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  Future<void> openSellerRegistration() async {
    final shop = TextEditingController();
    final owner = TextEditingController();
    final phone = TextEditingController();
    final address = TextEditingController();
    await showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      title: Text(t('Seller registration','বিক্রেতা নিবন্ধন')),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: shop, decoration: InputDecoration(labelText:t('Shop name','দোকানের নাম'))),
        const SizedBox(height:10),
        TextField(controller: owner, decoration: InputDecoration(labelText:t('Owner name','মালিকের নাম'))),
        const SizedBox(height:10),
        TextField(controller: phone, keyboardType:TextInputType.phone, decoration: InputDecoration(labelText:t('Phone number','মোবাইল নম্বর'))),
        const SizedBox(height:10),
        TextField(controller: address, decoration: InputDecoration(labelText:t('Shop address','দোকানের ঠিকানা'))),
      ])),
      actions: [
        TextButton(onPressed:()=>Navigator.pop(ctx), child:Text(t('Cancel','বাতিল'))),
        FilledButton(onPressed:(){
          if(shop.text.trim().isEmpty || owner.text.trim().isEmpty || phone.text.trim().isEmpty) {
            toast(t('Please complete required fields','প্রয়োজনীয় তথ্য পূরণ করুন')); return;
          }
          setState(()=>sellerStatus='Pending approval');
          Navigator.pop(ctx);
          toast(t('Application submitted. Admin approval is required.','আবেদন জমা হয়েছে। Admin অনুমোদন প্রয়োজন।'));
        }, child:Text(t('Submit','জমা দিন'))),
      ],
    ));
  }

  Future<void> addProduct() async {
    final name = TextEditingController();
    final price = TextEditingController();
    final category = TextEditingController();
    await showDialog<void>(context:context,builder:(ctx)=>AlertDialog(
      title:Text(t('Add product','পণ্য যোগ করুন')),
      content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:name,decoration:InputDecoration(labelText:t('Product name','পণ্যের নাম'))),
        const SizedBox(height:10),
        TextField(controller:price,keyboardType:TextInputType.number,decoration:InputDecoration(labelText:t('Price (BDT)','দাম (টাকা)'))),
        const SizedBox(height:10),
        TextField(controller:category,decoration:InputDecoration(labelText:t('Category','ক্যাটাগরি'))),
      ])),
      actions:[
        TextButton(onPressed:()=>Navigator.pop(ctx),child:Text(t('Cancel','বাতিল'))),
        FilledButton(onPressed:(){
          final amount=int.tryParse(price.text.trim());
          if(name.text.trim().isEmpty || amount==null || amount<1){toast(t('Enter a valid name and price','সঠিক নাম ও দাম দিন'));return;}
          setState(()=>pending.add(ShopProduct(name:name.text.trim(),category:category.text.trim().isEmpty?'General':category.text.trim(),price:amount,seller:'My Shop',approved:false)));
          Navigator.pop(ctx);
          toast(t('Product submitted for admin approval','পণ্য Admin অনুমোদনের জন্য জমা হয়েছে'));
        },child:Text(t('Submit','জমা দিন'))),
      ],
    ));
  }

  void approveProduct(ShopProduct p) {
    setState(() { p.approved=true; pending.remove(p); products.insert(0,p); });
    toast(t('Product approved and published','পণ্য অনুমোদিত ও প্রকাশিত হয়েছে'));
  }

  void checkout() {
    if(cart==0){toast(t('Your cart is empty','তোমার কার্ট খালি'));return;}
    setState(() { orders.insert(0,'Order #${DateTime.now().millisecondsSinceEpoch.toString().substring(7)} · $cart item(s) · COD'); cart=0; });
    toast(t('Demo order placed successfully','ডেমো অর্ডার সম্পন্ন হয়েছে'));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Row(children:[
        Container(width:34,height:34,decoration:BoxDecoration(color:green,borderRadius:BorderRadius.circular(10)),alignment:Alignment.center,child:const Text('E',style:TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.w900))),
        const SizedBox(width:9), const Text('Elyramart',style:TextStyle(fontWeight:FontWeight.w900,letterSpacing:-.4)),
      ]),
      actions:[
        IconButton(tooltip:'Language',onPressed:()=>setState(()=>isBengali=!isBengali),icon:const Icon(Icons.language)),
        IconButton(tooltip:'Cart',onPressed:()=>showCart(),icon:Badge(label:Text('$cart'),child:const Icon(Icons.shopping_cart_outlined))),
        const SizedBox(width:5),
      ],
    ),
    body: adminMode ? adminPage() : sellerMode ? sellerPage() : tab == 2 ? accountPage() : tab == 3 ? ordersPage() : customerPage(),
    bottomNavigationBar: NavigationBar(
      selectedIndex:tab,
      onDestinationSelected:(i)=>setState((){tab=i;adminMode=false;sellerMode=i==1;}),
      destinations:[
        NavigationDestination(icon:const Icon(Icons.storefront_outlined),selectedIcon:const Icon(Icons.storefront),label:t('Shop','কেনাকাটা')),
        NavigationDestination(icon:const Icon(Icons.store_mall_directory_outlined),selectedIcon:const Icon(Icons.store),label:t('Seller','বিক্রেতা')),
        NavigationDestination(icon:const Icon(Icons.person_outline),label:t('Account','অ্যাকাউন্ট')),
        NavigationDestination(icon:const Icon(Icons.receipt_long_outlined),label:t('Orders','অর্ডার')),
      ],
    ),
  );

  Widget customerPage() => CustomScrollView(slivers:[
    SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(16,8,16,10),child:TextField(
      controller:search,onChanged:(v)=>setState(()=>query=v),
      decoration:InputDecoration(hintText:t('Search products, shops and categories','পণ্য, দোকান ও ক্যাটাগরি খুঁজুন'),prefixIcon:const Icon(Icons.search),suffixIcon:const Icon(Icons.tune)),
    ))),
    SliverToBoxAdapter(child:Container(
      margin:const EdgeInsets.fromLTRB(16,4,16,18),padding:const EdgeInsets.all(20),
      decoration:BoxDecoration(borderRadius:BorderRadius.circular(22),gradient:const LinearGradient(colors:[green,darkGreen])),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('YOUR WORLD, YOUR CHOICE',style:TextStyle(color:Color(0xFFD4F4E5),fontSize:11,fontWeight:FontWeight.w800,letterSpacing:1)),
        const SizedBox(height:10),Text(t('Everything in one place','সবকিছু এক ঠিকানায়'),style:const TextStyle(color:Colors.white,fontSize:25,fontWeight:FontWeight.w900)),
        const SizedBox(height:6),Text(t('Shop smarter with Elyramart','Elyramart-এর সাথে সহজ কেনাকাটা'),style:const TextStyle(color:Colors.white70)),
        const SizedBox(height:15),FilledButton.tonal(onPressed:()=>setState(()=>selectedCategory='All'),style:FilledButton.styleFrom(backgroundColor:Colors.white,foregroundColor:green),child:Text(t('Shop now','এখনই কেনাকাটা করুন'))),
      ]),
    )),
    SliverToBoxAdapter(child:section(t('Shop by category','ক্যাটাগরি অনুযায়ী কিনুন'))),
    SliverToBoxAdapter(child:SizedBox(height:105,child:ListView(
      scrollDirection:Axis.horizontal,padding:const EdgeInsets.symmetric(horizontal:16),
      children:[
        ('All',Icons.apps),('Grocery',Icons.shopping_basket_outlined),('Health',Icons.health_and_safety_outlined),('Beauty',Icons.spa_outlined),('Fashion',Icons.checkroom_outlined),('Electronics',Icons.devices_outlined),('Home & Living',Icons.chair_outlined)
      ].map((c)=>GestureDetector(onTap:()=>setState(()=>selectedCategory=c.$1),child:Container(
        width:82,margin:const EdgeInsets.only(right:10),child:Column(children:[
          Container(height:58,width:58,decoration:BoxDecoration(color:selectedCategory==c.$1?pale:const Color(0xFFF0F5F2),borderRadius:BorderRadius.circular(17)),child:Icon(c.$2,color:green)),
          const SizedBox(height:6),Text(c.$1,style:const TextStyle(fontSize:10,fontWeight:FontWeight.w700),maxLines:1,overflow:TextOverflow.ellipsis)
        ]),
      )).toList(),
    ))),
    SliverToBoxAdapter(child:section(t('Popular products','জনপ্রিয় পণ্য'))),
    if(shown.isEmpty) SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.all(30),child:Center(child:Text(t('No products found','কোনো পণ্য পাওয়া যায়নি'))))),
    SliverPadding(padding:const EdgeInsets.fromLTRB(16,0,16,18),sliver:SliverGrid(
      delegate:SliverChildBuilderDelegate((ctx,i)=>productCard(shown[i]),childCount:shown.length),
      gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,mainAxisSpacing:12,crossAxisSpacing:12,childAspectRatio:.78),
    )),
    SliverToBoxAdapter(child:Container(
      margin:const EdgeInsets.fromLTRB(16,0,16,20),padding:const EdgeInsets.all(18),
      decoration:BoxDecoration(color:pale,borderRadius:BorderRadius.circular(18)),
      child:Row(children:[
        Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(t('Start selling with Elyramart','Elyramart-এর সাথে বিক্রি শুরু করুন'),style:const TextStyle(fontWeight:FontWeight.w900,fontSize:15)),
          const SizedBox(height:4),Text(t('Register your shop and grow your business.','দোকান নিবন্ধন করে ব্যবসা বাড়ান।'),style:const TextStyle(color:muted,fontSize:11)),
        ])),
        FilledButton(onPressed:()=>setState(()=>sellerMode=true),child:Text(t('Sell','বিক্রি করুন'))),
      ]),
    )),
  ]);

  Widget section(String title)=>Padding(padding:const EdgeInsets.fromLTRB(16,8,16,12),child:Text(title,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900)));

  Widget productCard(ShopProduct p)=>Card(
    elevation:0,color:Colors.white,clipBehavior:Clip.antiAlias,
    shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(17),side:const BorderSide(color:Color(0xFFE9EFEB))),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Expanded(child:Container(width:double.infinity,color:const Color(0xFFF0F5F2),child:const Icon(Icons.shopping_bag_outlined,size:48,color:Color(0xFF9AB7A7)))),
      Padding(padding:const EdgeInsets.fromLTRB(10,9,10,10),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(p.name,maxLines:1,overflow:TextOverflow.ellipsis,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:13)),
        Text(p.seller,style:const TextStyle(color:muted,fontSize:10)),
        const SizedBox(height:5),
        Row(children:[
          Expanded(child:Text('৳${p.price}',style:const TextStyle(color:green,fontWeight:FontWeight.w900))),
          InkWell(onTap:()=>setState(()=>cart++),child:const CircleAvatar(radius:16,backgroundColor:green,child:Icon(Icons.add,color:Colors.white,size:18))),
        ]),
      ])),
    ]),
  );

  Widget accountPage()=>ListView(padding:const EdgeInsets.all(16),children:[
    Text(t('My account','আমার অ্যাকাউন্ট'),style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900)),
    const SizedBox(height:14),
    const CircleAvatar(radius:34,backgroundColor:pale,child:Icon(Icons.person,color:green,size:36)),
    const SizedBox(height:12),
    Text(t('Welcome to Elyramart','Elyramart-এ স্বাগতম'),style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800)),
    const SizedBox(height:6),
    Text(t('Customer account demo. Secure login and profile storage will be added with the live backend.','কাস্টমার অ্যাকাউন্ট ডেমো। লাইভ Backend যুক্ত হলে নিরাপদ Login ও Profile যুক্ত হবে।'),style:const TextStyle(color:muted)),
    const SizedBox(height:18),
    ListTile(leading:const Icon(Icons.storefront,color:green),title:Text(t('Become a seller','বিক্রেতা হোন')),onTap:()=>setState((){sellerMode=true;tab=1;})),
    ListTile(leading:const Icon(Icons.receipt_long,color:green),title:Text(t('My orders','আমার অর্ডার')),onTap:()=>setState(()=>tab=3)),
  ]);

  Widget ordersPage()=>ListView(padding:const EdgeInsets.all(16),children:[
    Text(t('My orders','আমার অর্ডার'),style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900)),
    const SizedBox(height:12),
    if(orders.isEmpty) Padding(padding:const EdgeInsets.only(top:40),child:Center(child:Column(children:[const Icon(Icons.receipt_long_outlined,size:52,color:muted),const SizedBox(height:10),Text(t('No orders yet','এখনো কোনো অর্ডার নেই'),style:const TextStyle(color:muted))]))),
    ...orders.map((o)=>Card(elevation:0,child:ListTile(leading:const Icon(Icons.inventory_2_outlined,color:green),title:Text(o),subtitle:Text(t('Cash on Delivery · Demo','ক্যাশ অন ডেলিভারি · ডেমো'))))),
    const SizedBox(height:12),
    Text(t('Orders are stored only during this demo session.','ডেমো চলাকালীন অর্ডারগুলো সাময়িকভাবে সংরক্ষিত থাকে।'),style:const TextStyle(color:muted,fontSize:11)),
  ]);

  Widget adminPage()=>ListView(padding:const EdgeInsets.all(16),children:[
    Row(children:[Expanded(child:Text(t('Admin dashboard (demo)','Admin ড্যাশবোর্ড (ডেমো)'),style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900))),IconButton(onPressed:()=>setState(()=>adminMode=false),icon:const Icon(Icons.close))]),
    Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:pale,borderRadius:BorderRadius.circular(14)),child:Text(t('Demo controls only — this is not a secure admin login.','শুধু ডেমো কন্ট্রোল — এটি নিরাপদ Admin Login নয়।'),style:const TextStyle(color:darkGreen,fontWeight:FontWeight.w700))),
    const SizedBox(height:16),
    Text(t('Seller applications','বিক্রেতার আবেদন'),style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900)),
    const SizedBox(height:8),
    if(sellerStatus=='Pending approval') Card(elevation:0,child:ListTile(leading:const Icon(Icons.store,color:green),title:Text(t('My Shop application','My Shop-এর আবেদন')),subtitle:Text(sellerStatus),trailing:TextButton(onPressed:()=>setState(()=>sellerStatus='Approved'),child:Text(t('Approve','অনুমোদন'))))),
    if(sellerStatus!='Pending approval') Text(t('No pending seller applications.','কোনো অপেক্ষমাণ বিক্রেতার আবেদন নেই।'),style:const TextStyle(color:muted)),
    const SizedBox(height:16),
    Text(t('Product approvals','পণ্য অনুমোদন'),style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900)),
    if(pending.isEmpty) Text(t('No pending products.','কোনো অপেক্ষমাণ পণ্য নেই।'),style:const TextStyle(color:muted)),
    ...pending.map((p)=>Card(elevation:0,child:ListTile(title:Text(p.name),subtitle:Text('৳${p.price} · ${p.category}'),trailing:TextButton(onPressed:()=>approveProduct(p),child:Text(t('Approve','অনুমোদন')))))),
  ]);

  Widget sellerPage()=>ListView(padding:const EdgeInsets.all(16),children:[
    Row(children:[
      Expanded(child:Text(t('Seller Center','Seller Center'),style:const TextStyle(fontSize:24,fontWeight:FontWeight.w900))),
      TextButton.icon(onPressed:()=>setState(()=>sellerMode=false),icon:const Icon(Icons.storefront),label:Text(t('Shop mode','কাস্টমার'))),
    ]),
    Text(t('Register your shop and manage your products.','দোকান নিবন্ধন ও পণ্য পরিচালনা করুন।'),style:const TextStyle(color:muted)),
    const SizedBox(height:15),
    Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:pale,borderRadius:BorderRadius.circular(16)),child:Row(children:[
      const Icon(Icons.verified_user_outlined,color:green,size:30),const SizedBox(width:12),
      Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(t('Seller status','Seller স্ট্যাটাস'),style:const TextStyle(fontWeight:FontWeight.w800)),
        Text(sellerStatus,style:const TextStyle(color:muted,fontSize:12)),
      ])),
    ])),
    const SizedBox(height:14),
    if(sellerStatus=='Not registered') FilledButton.icon(onPressed:openSellerRegistration,icon:const Icon(Icons.app_registration),label:Text(t('Register as seller','Seller হিসেবে নিবন্ধন করুন')),style:FilledButton.styleFrom(minimumSize:const Size.fromHeight(50))),
    if(sellerStatus=='Pending approval') OutlinedButton.icon(onPressed:()=>toast(t('Please wait for admin review','Admin অনুমোদনের জন্য অপেক্ষা করুন')),icon:const Icon(Icons.hourglass_top),label:Text(t('Application pending','আবেদন যাচাই হচ্ছে'))),
    if(sellerStatus=='Approved') FilledButton.icon(onPressed:addProduct,icon:const Icon(Icons.add),label:Text(t('Add product','পণ্য যোগ করুন'))),
    const SizedBox(height:12),
    OutlinedButton.icon(onPressed:()=>setState(()=>adminMode=true),icon:const Icon(Icons.admin_panel_settings_outlined),label:Text(t('Open admin demo','Admin ডেমো খুলুন'))),
    const SizedBox(height:18),
    Text(t('My product submissions','আমার পণ্যের আবেদন'),style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900)),
    const SizedBox(height:8),
    if(pending.isEmpty) Text(t('No submitted products yet.','এখনো কোনো পণ্য জমা দেওয়া হয়নি।'),style:const TextStyle(color:muted)),
    ...pending.map((p)=>Card(elevation:0,child:ListTile(leading:const CircleAvatar(backgroundColor:pale,child:Icon(Icons.inventory_2_outlined,color:green)),title:Text(p.name),subtitle:Text('৳${p.price} · ${p.category}'),trailing:const Chip(label:Text('Pending')))),
    const SizedBox(height:20),
    const Text('Seller registration and product approval are demo-only until connected to the production backend.',style:TextStyle(color:muted,fontSize:11)),
  ]);

  Future<void> showCart() async {
    await showModalBottomSheet<void>(context:context,builder:(ctx)=>SafeArea(child:Padding(padding:const EdgeInsets.all(20),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(t('Your cart','তোমার কার্ট'),style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)),
      const SizedBox(height:8),Text('$cart ${t('item(s)','টি পণ্য')}'),
      const SizedBox(height:14),SizedBox(width:double.infinity,child:FilledButton(onPressed:(){Navigator.pop(ctx);checkout();},child:Text(t('Place demo COD order','ডেমো COD অর্ডার করুন')))),
      const SizedBox(height:8),Text(t('Demo checkout only. Live payment is not connected.','এটি ডেমো Checkout। বাস্তব পেমেন্ট এখনো যুক্ত নয়।'),style:const TextStyle(color:muted,fontSize:11)),
    ]))));
  }
}
