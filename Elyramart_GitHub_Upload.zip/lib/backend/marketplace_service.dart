import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// Firebase data layer for Elyramart. Configure Firebase for the Android app
/// before calling these methods. Never grant admin privileges from the client.
class MarketplaceService {
  MarketplaceService({FirebaseAuth? auth, FirebaseFirestore? db, FirebaseFunctions? functions})
      : _auth = auth ?? FirebaseAuth.instance,
        _db = db ?? FirebaseFirestore.instance,
        _functions = functions ?? FirebaseFunctions.instance;

  final FirebaseAuth _auth;
  final FirebaseFirestore _db;
  final FirebaseFunctions _functions;

  User? get currentUser => _auth.currentUser;
  bool get isSignedIn => currentUser != null;

  Future<void> sendPhoneOtp({
    required String phoneNumber,
    required void Function(String verificationId) onCodeSent,
    required void Function(FirebaseAuthException error) onError,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (credential) async {
        await _auth.signInWithCredential(credential);
        await _ensureCustomerProfile();
      },
      verificationFailed: onError,
      codeSent: (verificationId, _) => onCodeSent(verificationId),
      codeAutoRetrievalTimeout: onCodeSent,
    );
  }

  Future<UserCredential> confirmPhoneOtp({
    required String verificationId,
    required String smsCode,
  }) async {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );
    final result = await _auth.signInWithCredential(credential);
    await _ensureCustomerProfile();
    return result;
  }

  Future<void> _ensureCustomerProfile() async {
    final user = currentUser;
    if (user == null) throw StateError('Please sign in first.');
    final ref = _db.collection('users').doc(user.uid);
    final snap = await ref.get();
    if (!snap.exists) {
      await ref.set({
        'name': user.displayName ?? '',
        'phone': user.phoneNumber ?? '',
        'email': user.email,
        'role': 'customer',
        'createdAt': FieldValue.serverTimestamp(),
      });
    }
  }

  Future<void> signOut() => _auth.signOut();

  Stream<QuerySnapshot<Map<String, dynamic>>> watchApprovedProducts({String? category}) {
    Query<Map<String, dynamic>> query = _db.collection('products')
        .where('status', isEqualTo: 'approved');
    if (category != null && category.isNotEmpty && category != 'All') {
      query = query.where('category', isEqualTo: category);
    }
    return query.orderBy('createdAt', descending: true).snapshots();
  }

  Future<String> submitSellerApplication({
    required String shopName,
    required String ownerName,
    required String phone,
    required String address,
  }) async {
    final user = currentUser;
    if (user == null) throw StateError('Please sign in first.');
    final doc = await _db.collection('sellerApplications').add({
      'uid': user.uid,
      'shopName': shopName.trim(),
      'ownerName': ownerName.trim(),
      'phone': phone.trim(),
      'address': address.trim(),
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
    return doc.id;
  }

  Future<String> submitProduct({
    required String name,
    required String category,
    required num price,
    required int stock,
    String? imageUrl,
  }) async {
    final user = currentUser;
    if (user == null) throw StateError('Please sign in first.');
    if (price <= 0 || stock < 0) throw ArgumentError('Invalid price or stock.');
    final doc = await _db.collection('products').add({
      'sellerUid': user.uid,
      'name': name.trim(),
      'category': category.trim(),
      'price': price,
      'stock': stock,
      'imageUrl': imageUrl,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
    return doc.id;
  }

  /// Orders are created through a callable Cloud Function so price and stock
  /// are re-checked on the server. `items` must contain productId and quantity.
  Future<Map<String, dynamic>> placeCodOrder({
    required List<Map<String, dynamic>> items,
    required String customerName,
    required String phone,
    required String deliveryAddress,
  }) async {
    if (currentUser == null) throw StateError('Please sign in first.');
    final callable = _functions.httpsCallable('createCodOrder');
    final result = await callable.call<Map<String, dynamic>>({
      'items': items,
      'customerName': customerName.trim(),
      'phone': phone.trim(),
      'deliveryAddress': deliveryAddress.trim(),
    });
    return result.data;
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> watchMyOrders() {
    final user = currentUser;
    if (user == null) throw StateError('Please sign in first.');
    return _db.collection('orders')
        .where('customerUid', isEqualTo: user.uid)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  Future<void> approveSeller(String applicationId, String sellerUid) async {
    await _functions.httpsCallable('approveSeller').call({
      'applicationId': applicationId,
      'sellerUid': sellerUid,
    });
  }

  Future<void> approveProduct(String productId) async {
    await _functions.httpsCallable('approveProduct').call({'productId': productId});
  }

  /// Seller sees only orders that contain at least one of their products.
  Stream<QuerySnapshot<Map<String, dynamic>>> watchSellerOrders() {
    final user = currentUser;
    if (user == null) throw StateError('Please sign in first.');
    return _db.collection('orders')
        .where('sellerUids', arrayContains: user.uid)
        .orderBy('createdAt', descending: true)
        .snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> watchAdminOrders() =>
      _db.collection('orders').orderBy('createdAt', descending: true).snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> watchPendingSellerApplications() =>
      _db.collection('sellerApplications')
          .where('status', isEqualTo: 'pending')
          .orderBy('createdAt', descending: true).snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> watchPendingProducts() =>
      _db.collection('products')
          .where('status', isEqualTo: 'pending')
          .orderBy('createdAt', descending: true).snapshots();

  /// Seller/admin status changes are validated by the trusted Cloud Function.
  Future<void> updateOrderStatus({
    required String orderId,
    required String status,
  }) async {
    if (currentUser == null) throw StateError('Please sign in first.');
    await _functions.httpsCallable('updateOrderStatus').call({
      'orderId': orderId,
      'status': status,
    });
  }

  /// Admin cancellation restores stock in the trusted server transaction.
  Future<void> adminCancelOrder(String orderId) async {
    if (currentUser == null) throw StateError('Please sign in first.');
    await _functions.httpsCallable('adminCancelOrder').call({'orderId': orderId});
  }

  /// Customer may cancel only an order that has not been accepted yet.
  Future<void> cancelMyOrder(String orderId) async {
    if (currentUser == null) throw StateError('Please sign in first.');
    await _functions.httpsCallable('cancelMyOrder').call({'orderId': orderId});
  }

}
